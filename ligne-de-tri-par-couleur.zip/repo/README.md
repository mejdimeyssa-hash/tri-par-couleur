# Ligne de tri automatique par couleur

Mini-projet d'automatique, 1 GII 3, ENET'Com Sfax.
Auteurs : Meyssa Mejdi, Yasmine Youssfi. Encadrante : Mme Marwa Bouri.

Un convoyeur transporte des pièces bicolores. Un capteur lit la couleur, la pièce est mise dans une file FIFO, puis une trappe l'envoie dans le bac rouge ou le bac bleu quand elle arrive devant elle. Toute autre couleur est écartée sans perturber la ligne. La vitesse du tapis est régulée par un PI numérique.

![architecture](docs/architecture.png)

## Contenu

```
octave/        courbes (réponse indicielle, Bode, choc de charge, arrêt brusque, rejet de couleur)
arduino/       code carte réelle (ligne_de_tri) et calibration des couleurs
tinkercad/     version simulée pour Tinkercad Circuits
unity/         simulation 3D
docs/          figures
```

## Résultats

| Choc de charge +20 % | Arrêt brusque de 12 s |
|---|---|
| ![choc](docs/choc_charge.png) | ![arret](docs/arret_brusque.png) |

Le PI ramène la vitesse à 40 tr/min après un creux d'environ 3 tr/min. Sans correcteur, la vitesse tombe à 26 tr/min ; avec un P seul elle se stabilise à 20 puis 16 selon la perturbation. Au redémarrage après l'arrêt, le dépassement reste inférieur à 1 tr/min.

## Principe

### Régulation de vitesse

Moteur et tapis sont modélisés par un premier ordre `Km / (τm p + 1)` avec Km = 57,3 tr/min par unité de commande et τm = 0,8 s. Le PI est réglé par compensation du pôle (Kp = 1/Km, Ti = τm) et protégé contre la saturation par rétro-calcul.

```cpp
void regulerVitesse() {
  float erreur = CONSIGNE - vitesse;
  integrale += KI * TS * erreur;
  commande = KP * erreur + integrale;
  if (commande > 1.0) {
    integrale -= commande - 1.0;
    commande = 1.0;
  }
}
```

### Vitesse et position par l'encodeur

L'encodeur est lu en quadrature x4 par interruption. La position du tapis sert de base à tout le reste.

```cpp
float position() {
  return 2.0 * PI * RAYON * lireComptes() / (4.0 * IMPULSIONS_PAR_TOUR * REDUCTION);
}
```

### File FIFO et éjection

Chaque pièce lue est enregistrée avec la position du tapis à cet instant. La trappe est commandée quand la pièce en tête a parcouru la distance capteur-trappe moins ce que le tapis fait pendant le temps de réponse du servo.

```cpp
float avance = position() - p.x0;
if (avance >= DISTANCE_EJECTION - vitesseLineaire() * TEMPS_TRAPPE) {
  trappe.write(angleDeClasse(p.classe));
  etatTrappe = COMMANDE;
}
```

Deux machines à états séquentielles : lecture (ATTENTE, DETECTION, LECTURE, MEMORISATION) et trappe (SUIVI, COMMANDE, RETOUR).

### Classification

La couleur est ramenée à `r = R/(R+G+B)` et `g = G/(R+G+B)`, puis comparée aux centres du rouge et du bleu.

![classification](docs/classification.png)

```cpp
float dMin = min(dRouge, dBleu);
if (dMin > SEUIL_COULEUR) {
  return INCONNUE;
}
return dRouge < dBleu ? ROUGE : BLEU;
```

## Réactions aux perturbations (chapitre 4)

| Perturbation | Réaction |
|---|---|
| Couleur inconnue | pièce marquée INCONNUE, trappe neutre, pièce écartée, comptée à part |
| Panne du capteur | délai de sécurité de 300 ms, pièce inconnue, alimentation suspendue jusqu'au retour du capteur |
| Échauffement moteur | arrêt au-dessus de 70 °C ou 1,5 A, reprise sous 60 °C |
| Pièces rapprochées | espacement imposé par la distance parcourue du tapis, FIFO de 8 pièces |

## Utilisation

**Octave** : `cd octave`, puis `lancer_tout` ; les images sont écrites dans `octave/sorties`. Pas de paquet supplémentaire. `lire_journal('fichier.csv')` trace un journal enregistré depuis l'Arduino.

**Arduino** : ouvrir `arduino/ligne_de_tri/ligne_de_tri.ino`, installer la bibliothèque *Adafruit TCS34725*, téléverser. Moniteur série à 115200 bauds. Pour régler les centres de couleurs, téléverser d'abord `calibration_couleurs`, relever `r` et `g` de chaque pièce et reporter les valeurs dans `parametres.h`.

**Tinkercad** : voir `tinkercad/README.md`.

**Unity** : voir `unity/README.md`.

## Câblage de la carte réelle

| Broche | Fonction |
|---|---|
| 2, 3 | encodeur A, B |
| 4 | capteur IR (actif bas) |
| 5, 7, 8 | PWM et sens du pont en H |
| 6 | alimentation des pièces |
| 9 | servo de la trappe |
| 10, 11, 12 | LED rouge, bleue, défaut |
| A0 | température (TMP36) |
| A1 | courant (ACS712) |
| SDA, SCL | capteur TCS34725 |

## Limites

Le modèle est un premier ordre identifié sur le rapport ; les valeurs de couleur de la simulation sont à recalibrer avec les vraies pièces et l'éclairage du montage. Seul le code a été vérifié sur ordinateur ; le montage réel n'a pas été essayé.

## Licence

MIT.

#include <Wire.h>
#include <Adafruit_TCS34725.h>

Adafruit_TCS34725 capteur = Adafruit_TCS34725(TCS34725_INTEGRATIONTIME_50MS, TCS34725_GAIN_4X);

const int NOMBRE_MESURES = 20;

void setup() {
  Serial.begin(115200);
  if (!capteur.begin()) {
    Serial.println("capteur introuvable");
    while (true) {
    }
  }
  Serial.println("placer une piece sous le capteur");
}

void loop() {
  float sommeR = 0;
  float sommeG = 0;
  for (int i = 0; i < NOMBRE_MESURES; i++) {
    uint16_t r, g, b, c;
    capteur.getRawData(&r, &g, &b, &c);
    float somme = (float)r + g + b;
    if (somme > 0) {
      sommeR += r / somme;
      sommeG += g / somme;
    }
    delay(60);
  }
  Serial.print("r = ");
  Serial.print(sommeR / NOMBRE_MESURES, 3);
  Serial.print("   g = ");
  Serial.println(sommeG / NOMBRE_MESURES, 3);
  delay(1000);
}

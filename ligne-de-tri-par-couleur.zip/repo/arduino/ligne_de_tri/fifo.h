#ifndef FIFO_H
#define FIFO_H

#include <Arduino.h>

const byte ROUGE = 0;
const byte BLEU = 1;
const byte INCONNUE = 2;

const byte TAILLE_FIFO = 8;

struct Piece {
  byte classe;
  float x0;
};

Piece file[TAILLE_FIFO];
byte debut = 0;
byte nombre = 0;

bool fifoVide() {
  return nombre == 0;
}

bool fifoPleine() {
  return nombre == TAILLE_FIFO;
}

void fifoAjouter(byte classe, float x0) {
  if (fifoPleine()) {
    return;
  }
  byte fin = (debut + nombre) % TAILLE_FIFO;
  file[fin].classe = classe;
  file[fin].x0 = x0;
  nombre++;
}

Piece fifoTete() {
  return file[debut];
}

void fifoRetirer() {
  if (fifoVide()) {
    return;
  }
  debut = (debut + 1) % TAILLE_FIFO;
  nombre--;
}

#endif

#include <Wire.h>
#include <Servo.h>
#include <Adafruit_TCS34725.h>
#include "parametres.h"
#include "fifo.h"

Adafruit_TCS34725 capteur = Adafruit_TCS34725(TCS34725_INTEGRATIONTIME_50MS, TCS34725_GAIN_4X);
Servo trappe;

volatile long comptes = 0;
volatile byte ancienEtat = 0;
const int8_t TABLE_QUADRATURE[16] = {0, 1, -1, 0, -1, 0, 0, 1, 1, 0, 0, -1, 0, -1, 1, 0};

enum EtatLecture { ATTENTE, DETECTION, LECTURE, MEMORISATION };
enum EtatTrappe { SUIVI, COMMANDE, RETOUR };

EtatLecture etatLecture = ATTENTE;
EtatTrappe etatTrappe = SUIVI;

float vitesse = 0;
float integrale = 0;
float commande = 0;
long dernierComptage = 0;
unsigned long dernierCalcul = 0;

float temperature = 25;
float courant = 0;
bool moteurActif = true;

bool capteurOk = true;
unsigned long dernierControle = 0;

unsigned long debutEtat = 0;
byte classeLue = INCONNUE;
float xDerniereAlimentation = 0;
unsigned long debutAlimentation = 0;
bool alimentationEnCours = false;

byte classeEnCours = INCONNUE;
unsigned long debutTrappe = 0;

int nbRouge = 0;
int nbBleu = 0;
int nbInconnue = 0;

void lireEncodeur() {
  byte etat = (digitalRead(BROCHE_ENCODEUR_A) << 1) | digitalRead(BROCHE_ENCODEUR_B);
  comptes += TABLE_QUADRATURE[(ancienEtat << 2) | etat];
  ancienEtat = etat;
}

long lireComptes() {
  noInterrupts();
  long n = comptes;
  interrupts();
  return n;
}

float position() {
  return 2.0 * PI * RAYON * lireComptes() / (4.0 * IMPULSIONS_PAR_TOUR * REDUCTION);
}

float vitesseLineaire() {
  return vitesse * 2.0 * PI / 60.0 * RAYON;
}

void mesurerVitesse() {
  long n = lireComptes();
  long delta = n - dernierComptage;
  dernierComptage = n;
  vitesse = 60.0 * delta / (4.0 * IMPULSIONS_PAR_TOUR * REDUCTION * TS);
}

void regulerVitesse() {
  float erreur = CONSIGNE - vitesse;
  integrale += KI * TS * erreur;
  commande = KP * erreur + integrale;
  if (commande > 1.0) {
    integrale -= commande - 1.0;
    commande = 1.0;
  } else if (commande < 0.0) {
    integrale -= commande;
    commande = 0.0;
  }
}

void appliquerCommande() {
  if (!moteurActif) {
    analogWrite(BROCHE_PWM, 0);
    return;
  }
  digitalWrite(BROCHE_SENS_1, HIGH);
  digitalWrite(BROCHE_SENS_2, LOW);
  analogWrite(BROCHE_PWM, (int)(commande * 255));
}

void surveillerMoteur() {
  if (!SURVEILLANCE_MOTEUR) {
    return;
  }
  float tension = analogRead(BROCHE_TEMPERATURE) * 5.0 / 1023.0;
  temperature = (tension - 0.5) * 100.0;
  float tensionCourant = analogRead(BROCHE_COURANT) * 5.0 / 1023.0;
  courant = fabs((tensionCourant - 2.5) / 0.185);
  if (moteurActif && (temperature > TEMPERATURE_MAX || courant > COURANT_MAX)) {
    moteurActif = false;
    integrale = 0;
    Serial.println("# moteur arrete : temperature ou courant trop eleve");
  }
  if (!moteurActif && temperature < TEMPERATURE_REPRISE && courant < COURANT_MAX) {
    moteurActif = true;
    Serial.println("# moteur remis en marche");
  }
}

bool capteurPresent() {
  Wire.beginTransmission(0x29);
  return Wire.endTransmission() == 0;
}

void surveillerCapteur() {
  if (millis() - dernierControle < CONTROLE_CAPTEUR_MS) {
    return;
  }
  dernierControle = millis();
  bool present = capteurPresent();
  if (capteurOk && !present) {
    capteurOk = false;
    Serial.println("# capteur de couleur absent");
  }
  if (!capteurOk && present) {
    capteur.begin();
    capteurOk = true;
    Serial.println("# capteur de couleur de retour");
  }
}

float distance(float r1, float g1, float r2, float g2) {
  return sqrt((r1 - r2) * (r1 - r2) + (g1 - g2) * (g1 - g2));
}

byte classer(uint16_t r, uint16_t g, uint16_t b) {
  float somme = (float)r + g + b;
  if (somme < 1) {
    return INCONNUE;
  }
  float rn = r / somme;
  float gn = g / somme;
  float dRouge = distance(rn, gn, CENTRE_ROUGE_R, CENTRE_ROUGE_G);
  float dBleu = distance(rn, gn, CENTRE_BLEU_R, CENTRE_BLEU_G);
  float dMin = min(dRouge, dBleu);
  if (dMin > SEUIL_COULEUR) {
    return INCONNUE;
  }
  if (dRouge < dBleu) {
    return ROUGE;
  }
  return BLEU;
}

bool lireCouleur(byte &classe) {
  if (!capteurPresent()) {
    return false;
  }
  uint16_t r, g, b, c;
  capteur.getRawData(&r, &g, &b, &c);
  if (c < CLAIR_MIN || c >= 65535) {
    return false;
  }
  classe = classer(r, g, b);
  return true;
}

void gererLecture() {
  switch (etatLecture) {
    case ATTENTE:
      if (digitalRead(BROCHE_IR) == LOW && capteurOk) {
        debutEtat = millis();
        etatLecture = DETECTION;
      } else if (digitalRead(BROCHE_IR) == LOW && !capteurOk) {
        fifoAjouter(INCONNUE, position());
        etatLecture = MEMORISATION;
      }
      break;
    case DETECTION:
      if (millis() - debutEtat >= DELAI_CENTRAGE_MS) {
        debutEtat = millis();
        etatLecture = LECTURE;
      }
      break;
    case LECTURE:
      if (lireCouleur(classeLue)) {
        fifoAjouter(classeLue, position());
        etatLecture = MEMORISATION;
      } else if (millis() - debutEtat >= DELAI_LECTURE_MS) {
        capteurOk = false;
        fifoAjouter(INCONNUE, position());
        Serial.println("# lecture impossible : piece inconnue");
        etatLecture = MEMORISATION;
      }
      break;
    case MEMORISATION:
      if (digitalRead(BROCHE_IR) == HIGH) {
        etatLecture = ATTENTE;
      }
      break;
  }
}

int angleDeClasse(byte classe) {
  if (classe == ROUGE) {
    return ANGLE_ROUGE;
  }
  if (classe == BLEU) {
    return ANGLE_BLEU;
  }
  return ANGLE_NEUTRE;
}

void gererTrappe() {
  switch (etatTrappe) {
    case SUIVI:
      if (!fifoVide()) {
        Piece p = fifoTete();
        float avance = position() - p.x0;
        if (avance >= DISTANCE_EJECTION - vitesseLineaire() * TEMPS_TRAPPE) {
          classeEnCours = p.classe;
          trappe.write(angleDeClasse(classeEnCours));
          if (classeEnCours == ROUGE) {
            digitalWrite(BROCHE_LED_ROUGE, HIGH);
          } else if (classeEnCours == BLEU) {
            digitalWrite(BROCHE_LED_BLEU, HIGH);
          }
          etatTrappe = COMMANDE;
        }
      }
      break;
    case COMMANDE:
      if (position() - fifoTete().x0 >= DISTANCE_EJECTION + MARGE_PASSAGE) {
        trappe.write(ANGLE_NEUTRE);
        debutTrappe = millis();
        etatTrappe = RETOUR;
      }
      break;
    case RETOUR:
      if (millis() - debutTrappe >= TEMPS_TRAPPE * 1000) {
        if (classeEnCours == ROUGE) {
          nbRouge++;
        } else if (classeEnCours == BLEU) {
          nbBleu++;
        } else {
          nbInconnue++;
        }
        digitalWrite(BROCHE_LED_ROUGE, LOW);
        digitalWrite(BROCHE_LED_BLEU, LOW);
        fifoRetirer();
        etatTrappe = SUIVI;
      }
      break;
  }
}

void gererAlimentation() {
  float espacement = CONSIGNE * 2.0 * PI / 60.0 * RAYON * ESPACEMENT_S;
  bool autorisee = moteurActif && capteurOk && !fifoPleine();
  if (alimentationEnCours) {
    if (millis() - debutAlimentation >= IMPULSION_ALIMENTATION_MS) {
      digitalWrite(BROCHE_ALIMENTATION, LOW);
      alimentationEnCours = false;
    }
    return;
  }
  if (autorisee && position() - xDerniereAlimentation >= espacement) {
    digitalWrite(BROCHE_ALIMENTATION, HIGH);
    debutAlimentation = millis();
    alimentationEnCours = true;
    xDerniereAlimentation = position();
  }
}

void afficherJournal() {
  Serial.print(millis() / 1000.0, 1);
  Serial.print(",");
  Serial.print(CONSIGNE, 1);
  Serial.print(",");
  Serial.print(vitesse, 1);
  Serial.print(",");
  Serial.print(commande, 2);
  Serial.print(",");
  Serial.print(nbRouge);
  Serial.print(",");
  Serial.print(nbBleu);
  Serial.print(",");
  Serial.println(nbInconnue);
}

void setup() {
  Serial.begin(115200);
  Wire.begin();
  pinMode(BROCHE_ENCODEUR_A, INPUT_PULLUP);
  pinMode(BROCHE_ENCODEUR_B, INPUT_PULLUP);
  pinMode(BROCHE_IR, INPUT_PULLUP);
  pinMode(BROCHE_PWM, OUTPUT);
  pinMode(BROCHE_ALIMENTATION, OUTPUT);
  pinMode(BROCHE_SENS_1, OUTPUT);
  pinMode(BROCHE_SENS_2, OUTPUT);
  pinMode(BROCHE_LED_ROUGE, OUTPUT);
  pinMode(BROCHE_LED_BLEU, OUTPUT);
  pinMode(BROCHE_LED_DEFAUT, OUTPUT);
  trappe.attach(BROCHE_SERVO);
  trappe.write(ANGLE_NEUTRE);
  ancienEtat = (digitalRead(BROCHE_ENCODEUR_A) << 1) | digitalRead(BROCHE_ENCODEUR_B);
  attachInterrupt(digitalPinToInterrupt(BROCHE_ENCODEUR_A), lireEncodeur, CHANGE);
  attachInterrupt(digitalPinToInterrupt(BROCHE_ENCODEUR_B), lireEncodeur, CHANGE);
  capteurOk = capteur.begin();
  Serial.println("temps,consigne,vitesse,commande,rouge,bleu,inconnue");
}

void loop() {
  surveillerCapteur();
  gererLecture();
  gererTrappe();
  gererAlimentation();
  digitalWrite(BROCHE_LED_DEFAUT, (!capteurOk || !moteurActif) ? HIGH : LOW);
  if (millis() - dernierCalcul >= PERIODE_MS) {
    dernierCalcul = millis();
    mesurerVitesse();
    surveillerMoteur();
    regulerVitesse();
    appliquerCommande();
    afficherJournal();
  }
}

#ifndef PARAMETRES_H
#define PARAMETRES_H

#include <Arduino.h>

const byte BROCHE_ENCODEUR_A = 2;
const byte BROCHE_ENCODEUR_B = 3;
const byte BROCHE_IR = 4;
const byte BROCHE_PWM = 5;
const byte BROCHE_ALIMENTATION = 6;
const byte BROCHE_SENS_1 = 7;
const byte BROCHE_SENS_2 = 8;
const byte BROCHE_SERVO = 9;
const byte BROCHE_LED_ROUGE = 10;
const byte BROCHE_LED_BLEU = 11;
const byte BROCHE_LED_DEFAUT = 12;
const byte BROCHE_TEMPERATURE = A0;
const byte BROCHE_COURANT = A1;

const float CONSIGNE = 40.0;
const float KM = 57.3;
const float TAU_M = 0.8;
const float TAU_BF = 0.8;
const float KP = TAU_M / (TAU_BF * KM);
const float TI = TAU_M;
const float KI = KP / TI;
const unsigned long PERIODE_MS = 100;
const float TS = PERIODE_MS / 1000.0;

const int IMPULSIONS_PAR_TOUR = 11;
const int REDUCTION = 30;
const float RAYON = 0.05;

const float DISTANCE_EJECTION = 1.2;
const float MARGE_PASSAGE = 0.08;
const float TEMPS_TRAPPE = 0.3;
const float ESPACEMENT_S = 5.0;

const int ANGLE_ROUGE = 40;
const int ANGLE_NEUTRE = 90;
const int ANGLE_BLEU = 140;

const float CENTRE_ROUGE_R = 0.62;
const float CENTRE_ROUGE_G = 0.21;
const float CENTRE_BLEU_R = 0.18;
const float CENTRE_BLEU_G = 0.31;
const float SEUIL_COULEUR = 0.15;

const unsigned long DELAI_CENTRAGE_MS = 60;
const unsigned long DELAI_LECTURE_MS = 300;
const unsigned long CONTROLE_CAPTEUR_MS = 500;
const unsigned int CLAIR_MIN = 50;

const bool SURVEILLANCE_MOTEUR = true;
const float TEMPERATURE_MAX = 70.0;
const float TEMPERATURE_REPRISE = 60.0;
const float COURANT_MAX = 1.5;

const unsigned long IMPULSION_ALIMENTATION_MS = 150;

#endif

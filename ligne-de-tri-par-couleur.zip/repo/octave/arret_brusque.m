p = parametres();
T = 70;
blocage = [22 34];
[t, w_p] = simuler_boucle('P', T, Inf, blocage, p);
[t, w_pi] = simuler_boucle('PI', T, Inf, blocage, p);
[t, w_pid] = simuler_boucle('PID', T, Inf, blocage, p);

figure(4);
clf;
plot(t, w_p, 'k', 'linewidth', 1);
hold on;
plot(t, w_pi, 'b', 'linewidth', 1);
plot(t, w_pid, 'r', 'linewidth', 3);
plot([0 T], [p.wref p.wref], 'g--', 'linewidth', 2);
patch([blocage(1) blocage(2) blocage(2) blocage(1)], [52 52 55 55], 'm', 'edgecolor', 'm');
plot([blocage(1) blocage(1)], [0 60], 'm:');
plot([blocage(2) blocage(2)], [0 60], 'm:');
text(blocage(1), 57, 'Arret : t = 22 s -> 34 s (duree 12 s)', 'color', 'm');
grid on;
xlabel('t (s)');
ylabel('\omega (tr/min)');
title('Arret brusque du convoyeur : comparaison des correcteurs P, PI et PID');
legend('Correcteur P', 'Correcteur PI', 'Correcteur PID', 'Consigne', 'Duree de l arret : 12 s', 'location', 'southeast');
axis([0 T 0 60]);

mkdir_sorties();
print('-dpng', '-r150', 'sorties/arret_brusque.png');

i2 = round(blocage(2) / p.dt);
printf('P   : plateau %.1f tr/min\n', w_p(end));
printf('PI  : pic apres reprise %.1f tr/min, final %.1f tr/min\n', max(w_pi(i2:end)), w_pi(end));
printf('PID : pic apres reprise %.1f tr/min, final %.1f tr/min\n', max(w_pid(i2:end)), w_pid(end));

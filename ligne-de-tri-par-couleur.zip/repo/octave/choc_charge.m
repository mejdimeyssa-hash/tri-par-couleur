p = parametres();
T = 20;
t_choc = 10;
[t, w_bo] = simuler_boucle('BO', T, t_choc, [], p);
[t, w_p] = simuler_boucle('P', T, t_choc, [], p);
[t, w_pi] = simuler_boucle('PI', T, t_choc, [], p);
[t, w_pid] = simuler_boucle('PID', T, t_choc, [], p);

figure(3);
clf;
plot(t, w_bo, 'g', 'linewidth', 2);
hold on;
plot(t, w_p, 'k', 'linewidth', 2);
plot(t, w_pi, 'b', 'linewidth', 2);
plot(t, w_pid, 'r', 'linewidth', 2);
plot([0 T], [p.wref p.wref], 'g--');
plot([t_choc t_choc], [0 45], 'm:', 'linewidth', 1.5);
grid on;
xlabel('Temps (s)');
ylabel('Vitesse (tr/min)');
title('Comparaison sans correcteur, P, PI et PID sous perturbation');
legend('Sans correcteur', 'Correcteur P', 'Correcteur PI', 'Correcteur PID', 'Consigne', 'Perturbation', 'location', 'southeast');
axis([0 T 0 45]);

mkdir_sorties();
print('-dpng', '-r150', 'sorties/choc_charge.png');

i1 = round(t_choc / p.dt);
printf('Sans correcteur : %.1f puis %.1f tr/min\n', w_bo(i1), w_bo(end));
printf('P               : %.1f puis %.1f tr/min\n', w_p(i1), w_p(end));
printf('PI              : %.1f, creux %.1f, final %.1f tr/min\n', w_pi(i1), min(w_pi(i1:end)), w_pi(end));
printf('PID             : %.1f, creux %.1f, final %.1f tr/min\n', w_pid(i1), min(w_pid(i1:end)), w_pid(end));

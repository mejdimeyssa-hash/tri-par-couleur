p = parametres();
w = logspace(-2, 2, 500);
H = p.Km_rads ./ (1 + 1i * w * p.tau);
gain = 20 * log10(abs(H));
phase = angle(H) * 180 / pi;
wc = 1 / p.tau;
gain_c = 20 * log10(p.Km_rads / sqrt(2));
asympt = 20 * log10(p.Km_rads) - 20 * log10(max(w / wc, 1));

figure(2);
clf;
subplot(2, 1, 1);
semilogx(w, gain, 'k', 'linewidth', 3);
hold on;
semilogx(w, asympt, 'r--', 'linewidth', 1.5);
semilogx(wc, gain_c, 'ro', 'markersize', 8, 'markerfacecolor', 'r');
grid on;
ylabel('Gain (dB)');
title('Diagramme de Bode du systeme seul G(p)');
legend('Courbe reelle', 'Asymptotes', 'Pulsation de coupure', 'location', 'southwest');

subplot(2, 1, 2);
semilogx(w, phase, 'k', 'linewidth', 3);
hold on;
semilogx(wc, -45, 'ro', 'markersize', 8, 'markerfacecolor', 'r');
semilogx([w(1) w(end)], [-90 -90], 'r--');
grid on;
xlabel('Pulsation \omega (rad/s)');
ylabel('Phase (degres)');

mkdir_sorties();
print('-dpng', '-r150', 'sorties/bode.png');
printf('gain basses frequences = %.1f dB, wc = %.2f rad/s\n', 20 * log10(p.Km_rads), wc);

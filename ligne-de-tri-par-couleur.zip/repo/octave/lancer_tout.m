close all;
reponse_indicielle;
diagramme_bode;
choc_charge;
arret_brusque;
rejet_couleur;
disp('Figures enregistrees dans le dossier sorties');

function J = lire_journal(fichier)
  f = fopen(fichier, 'r');
  J = [];
  ligne = fgetl(f);
  while ischar(ligne)
    if ~isempty(ligne) && any(ligne(1) == '0123456789')
      J = [J; sscanf(ligne, '%f,')'];
    end
    ligne = fgetl(f);
  end
  fclose(f);
  figure(6);
  clf;
  subplot(2, 1, 1);
  plot(J(:, 1), J(:, 2), 'g--', J(:, 1), J(:, 3), 'b', 'linewidth', 2);
  grid on;
  ylabel('Vitesse (tr/min)');
  legend('Consigne', 'Mesure');
  subplot(2, 1, 2);
  plot(J(:, 1), J(:, 4), 'k', 'linewidth', 2);
  grid on;
  xlabel('Temps (s)');
  ylabel('Commande');
end

function mkdir_sorties()
  if ~exist('sorties', 'dir')
    mkdir('sorties');
  end
end

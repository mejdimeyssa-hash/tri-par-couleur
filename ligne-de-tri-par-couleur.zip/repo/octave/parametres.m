function p = parametres()
  p.Km_rads = 6;
  p.Km = p.Km_rads * 60 / (2 * pi);
  p.tau = 0.8;
  p.wref = 40;
  p.d0 = 0.2 * p.wref;
  p.umax = 1;
  p.taucl = 0.8;
  p.Kp = p.tau / (p.taucl * p.Km);
  p.Ti = p.tau;
  p.Td = 0.05;
  p.Tf = 0.01;
  p.dt = 0.01;
  p.u_bo = 0.5934;
  p.seuil = 0.15;
  p.centre_rouge = [0.62 0.21];
  p.centre_bleu = [0.18 0.31];
end

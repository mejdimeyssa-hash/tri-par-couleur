p = parametres();
mesures = [
  0.64 0.20
  0.19 0.32
  0.60 0.22
  0.17 0.30
  0.20 0.70
  0.21 0.31
  0.63 0.19
  0.52 0.56
  0.61 0.23
  0.16 0.33
];
n = size(mesures, 1);
dist = zeros(n, 1);
for k = 1:n
  dr = norm(mesures(k, :) - p.centre_rouge);
  db = norm(mesures(k, :) - p.centre_bleu);
  dist(k) = min(dr, db);
end
inconnue = dist > p.seuil;

figure(5);
clf;
bar(1:n, dist, 0.6, 'facecolor', [0.2 0.5 0.8]);
hold on;
for k = 1:n
  if inconnue(k)
    bar(k, dist(k), 0.6, 'facecolor', [0.85 0.2 0.2]);
  end
end
plot([0 n + 1], [p.seuil p.seuil], 'k--', 'linewidth', 2);
text(0.6, p.seuil + 0.015, 'seuil de rejet = 0.15');
grid on;
xlabel('Numero de la piece');
ylabel('Distance au centroide le plus proche');
title('Detection et rejet des pieces de couleur inconnue');
axis([0 n + 1 0 0.5]);

mkdir_sorties();
print('-dpng', '-r150', 'sorties/rejet_couleur.png');

for k = 1:n
  if inconnue(k)
    printf('piece %2d : distance %.2f -> inconnue, trappe neutre\n', k, dist(k));
  else
    printf('piece %2d : distance %.2f -> classee\n', k, dist(k));
  end
end

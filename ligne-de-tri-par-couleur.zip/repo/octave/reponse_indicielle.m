p = parametres();
t = linspace(0, 4, 400);
y = p.Km_rads * (1 - exp(-t / p.tau));
tr5 = 3 * p.tau;

figure(1);
clf;
plot(t, y, 'k', 'linewidth', 3);
hold on;
plot([0 4], [p.Km_rads p.Km_rads], 'k--');
plot([0 4], [0.95 * p.Km_rads 0.95 * p.Km_rads], 'k:');
plot(p.tau, p.Km_rads * 0.632, 'ko', 'markersize', 8, 'markerfacecolor', 'k');
plot(tr5, p.Km_rads * 0.95, 'rs', 'markersize', 9, 'markerfacecolor', 'r');
plot([p.tau p.tau], [0 p.Km_rads * 0.632], 'k:');
plot([tr5 tr5], [0 p.Km_rads * 0.95], 'r:');
text(p.tau + 0.05, 2.5, '63 % a t = \tau_m');
text(tr5 + 0.05, 4.5, 't_{r5%} = 2.40 s', 'color', 'r');
grid on;
xlabel('Temps (s)');
ylabel('Vitesse \omega (rad/s)');
title('Reponse indicielle du systeme seul G(p)');
legend('Reponse indicielle', 'Gain statique K_m', 'Bande de 95 %', 'location', 'southeast');
axis([0 4 0 6.5]);

mkdir_sorties();
print('-dpng', '-r150', 'sorties/reponse_indicielle.png');
printf('Km = %.1f rad/s, tau = %.1f s, tr5%% = %.2f s\n', p.Km_rads, p.tau, tr5);

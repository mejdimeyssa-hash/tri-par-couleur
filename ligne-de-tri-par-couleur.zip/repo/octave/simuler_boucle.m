function [t, w, u] = simuler_boucle(type, T, t_choc, blocage, p)
  n = round(T / p.dt) + 1;
  t = (0:n-1)' * p.dt;
  w = zeros(n, 1);
  u = zeros(n, 1);
  a = exp(-p.dt / p.tau);
  I = 0;
  D = 0;
  for k = 1:n-1
    d = 0;
    if t(k) >= t_choc
      d = p.d0;
    end
    e = p.wref - w(k);
    if strcmp(type, 'BO')
      uk = p.u_bo;
    elseif strcmp(type, 'P')
      uk = p.Kp * e;
    else
      I = I + p.Kp / p.Ti * p.dt * e;
      if strcmp(type, 'PID')
        al = p.Tf / (p.Tf + p.dt);
        dy = 0;
        if k > 1
          dy = w(k) - w(k-1);
        end
        D = al * D - (1 - al) * p.Kp * p.Td * dy / p.dt;
      end
      uk = p.Kp * e + I + D;
      if uk > p.umax
        I = I - (uk - p.umax);
        uk = p.umax;
      elseif uk < 0
        I = I - uk;
        uk = 0;
      end
    end
    u(k) = uk;
    w(k+1) = a * w(k) + (1 - a) * (p.Km * uk - d);
    if w(k+1) < 0
      w(k+1) = 0;
    end
    if ~isempty(blocage)
      if t(k+1) >= blocage(1) && t(k+1) < blocage(2)
        w(k+1) = 0;
      end
    end
  end
  u(n) = u(n-1);
end

# Version Tinkercad Circuits

Un seul fichier : `tri_tinkercad.ino`. Tinkercad n'a ni capteur TCS34725 ni encodeur : le moteur, la position du tapis et la couleur sont donc simulés par le code, avec les mêmes paramètres que la version carte réelle.

## Composants

| Composant | Broche | Rôle |
|---|---|---|
| Bouton poussoir | D2 (vers GND) | présence d'une pièce (capteur IR) |
| Interrupteur | D3 (vers GND) | charge +20 % |
| Interrupteur | D4 (vers GND) | panne du capteur de couleur (fermé = panne) |
| L293D (entrée) | D5 PWM, D7, D8 | pont en H du moteur |
| LED verte | D6 | impulsion d'alimentation |
| Servomoteur | D9 | trappe |
| LED rouge / bleue | D10 / D11 | bac choisi |
| LED orange | D12 | défaut |
| Potentiomètres | A0, A1, A2 | R, G, B simulés |
| TMP36 | A3 | température moteur |

Interrupteur D4 ouvert : capteur présent. Fermé vers GND : panne simulée.

## Valeurs des potentiomètres (0 à 1023)

| Pièce | A0 (R) | A1 (G) | A2 (B) |
|---|---|---|---|
| Rouge | 900 | 250 | 200 |
| Bleue | 150 | 300 | 800 |
| Verte (inconnue) | 150 | 800 | 150 |
| Jaune (inconnue) | 800 | 800 | 100 |

## Utilisation

1. Créer un circuit, placer les composants du tableau, copier le code.
2. Lancer la simulation, ouvrir le moniteur série : le CSV `temps,consigne,vitesse,commande,rouge,bleu,inconnue` s'affiche chaque seconde, les événements commencent par `#`.
3. Régler les potentiomètres, appuyer sur le bouton D2 environ 0,4 s : la pièce est mémorisée dans la FIFO, puis la trappe s'oriente quand elle atteint 1,2 m.
4. Fermer D3 pour la charge, fermer D4 pour la panne capteur, monter le TMP36 au-dessus de 70 °C pour la surchauffe.

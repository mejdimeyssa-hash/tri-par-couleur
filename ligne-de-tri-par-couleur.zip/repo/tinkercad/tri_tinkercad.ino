#include <Servo.h>

const byte BROCHE_BOUTON_PIECE = 2;
const byte BROCHE_INTER_CHARGE = 3;
const byte BROCHE_INTER_CAPTEUR = 4;
const byte BROCHE_PWM = 5;
const byte BROCHE_LED_ALIMENTATION = 6;
const byte BROCHE_SENS_1 = 7;
const byte BROCHE_SENS_2 = 8;
const byte BROCHE_SERVO = 9;
const byte BROCHE_LED_ROUGE = 10;
const byte BROCHE_LED_BLEU = 11;
const byte BROCHE_LED_DEFAUT = 12;
const byte BROCHE_POT_R = A0;
const byte BROCHE_POT_G = A1;
const byte BROCHE_POT_B = A2;
const byte BROCHE_TEMPERATURE = A3;

const float CONSIGNE = 40.0;
const float KM = 57.3;
const float TAU_M = 0.8;
const float TAU_BF = 0.8;
const float KP = TAU_M / (TAU_BF * KM);
const float TI = TAU_M;
const float KI = KP / TI;
const unsigned long PERIODE_MS = 100;
const float TS = PERIODE_MS / 1000.0;

const float RAYON = 0.05;
const float DISTANCE_EJECTION = 1.2;
const float MARGE_PASSAGE = 0.08;
const float TEMPS_TRAPPE = 0.3;
const float ESPACEMENT_S = 5.0;

const int ANGLE_ROUGE = 40;
const int ANGLE_NEUTRE = 90;
const int ANGLE_BLEU = 140;

const float CENTRE_ROUGE_R = 0.66;
const float CENTRE_ROUGE_G = 0.19;
const float CENTRE_BLEU_R = 0.12;
const float CENTRE_BLEU_G = 0.24;
const float SEUIL_COULEUR = 0.15;

const unsigned long DELAI_CENTRAGE_MS = 60;
const unsigned long DELAI_LECTURE_MS = 300;
const int SOMME_MIN = 30;

const float TEMPERATURE_MAX = 70.0;
const float TEMPERATURE_REPRISE = 60.0;

const unsigned long IMPULSION_ALIMENTATION_MS = 300;
const unsigned long PERIODE_JOURNAL_MS = 1000;

const byte ROUGE = 0;
const byte BLEU = 1;
const byte INCONNUE = 2;

const byte TAILLE_FIFO = 8;

struct Piece {
  byte classe;
  float x0;
};

Piece file[TAILLE_FIFO];
byte debut = 0;
byte nombre = 0;

enum EtatLecture { ATTENTE, DETECTION, LECTURE, MEMORISATION };
enum EtatTrappe { SUIVI, COMMANDE, RETOUR };

EtatLecture etatLecture = ATTENTE;
EtatTrappe etatTrappe = SUIVI;

Servo trappe;

float vitesse = 0;
float integrale = 0;
float commande = 0;
float positionTapis = 0;
unsigned long dernierCalcul = 0;
unsigned long dernierJournal = 0;

float temperature = 25;
bool moteurActif = true;
bool capteurOk = true;

unsigned long debutEtat = 0;
byte classeLue = INCONNUE;
float xDerniereAlimentation = 0;
unsigned long debutAlimentation = 0;
bool alimentationEnCours = false;

byte classeEnCours = INCONNUE;
unsigned long debutTrappe = 0;

int nbRouge = 0;
int nbBleu = 0;
int nbInconnue = 0;

bool fifoVide() {
  return nombre == 0;
}

bool fifoPleine() {
  return nombre == TAILLE_FIFO;
}

void fifoAjouter(byte classe, float x0) {
  if (fifoPleine()) {
    return;
  }
  byte fin = (debut + nombre) % TAILLE_FIFO;
  file[fin].classe = classe;
  file[fin].x0 = x0;
  nombre++;
}

Piece fifoTete() {
  return file[debut];
}

void fifoRetirer() {
  if (fifoVide()) {
    return;
  }
  debut = (debut + 1) % TAILLE_FIFO;
  nombre--;
}

float vitesseLineaire() {
  return vitesse * 2.0 * PI / 60.0 * RAYON;
}

void simulerMoteur() {
  float perturbation = 0;
  if (digitalRead(BROCHE_INTER_CHARGE) == LOW) {
    perturbation = 0.2 * CONSIGNE;
  }
  float u = moteurActif ? commande : 0;
  float a = exp(-TS / TAU_M);
  vitesse = a * vitesse + (1 - a) * (KM * u - perturbation);
  if (vitesse < 0) {
    vitesse = 0;
  }
  positionTapis += vitesseLineaire() * TS;
}

void regulerVitesse() {
  float erreur = CONSIGNE - vitesse;
  integrale += KI * TS * erreur;
  commande = KP * erreur + integrale;
  if (commande > 1.0) {
    integrale -= commande - 1.0;
    commande = 1.0;
  } else if (commande < 0.0) {
    integrale -= commande;
    commande = 0.0;
  }
}

void appliquerCommande() {
  if (!moteurActif) {
    analogWrite(BROCHE_PWM, 0);
    return;
  }
  digitalWrite(BROCHE_SENS_1, HIGH);
  digitalWrite(BROCHE_SENS_2, LOW);
  analogWrite(BROCHE_PWM, (int)(commande * 255));
}

void surveillerMoteur() {
  float tension = analogRead(BROCHE_TEMPERATURE) * 5.0 / 1023.0;
  temperature = (tension - 0.5) * 100.0;
  if (moteurActif && temperature > TEMPERATURE_MAX) {
    moteurActif = false;
    integrale = 0;
    Serial.println("# moteur arrete : temperature trop elevee");
  }
  if (!moteurActif && temperature < TEMPERATURE_REPRISE) {
    moteurActif = true;
    Serial.println("# moteur remis en marche");
  }
}

void surveillerCapteur() {
  bool present = digitalRead(BROCHE_INTER_CAPTEUR) == HIGH;
  if (capteurOk && !present) {
    capteurOk = false;
    Serial.println("# capteur de couleur absent");
  }
  if (!capteurOk && present) {
    capteurOk = true;
    Serial.println("# capteur de couleur de retour");
  }
}

float distance(float r1, float g1, float r2, float g2) {
  return sqrt((r1 - r2) * (r1 - r2) + (g1 - g2) * (g1 - g2));
}

byte classer(int r, int g, int b) {
  float somme = (float)r + g + b;
  if (somme < 1) {
    return INCONNUE;
  }
  float rn = r / somme;
  float gn = g / somme;
  float dRouge = distance(rn, gn, CENTRE_ROUGE_R, CENTRE_ROUGE_G);
  float dBleu = distance(rn, gn, CENTRE_BLEU_R, CENTRE_BLEU_G);
  float dMin = min(dRouge, dBleu);
  if (dMin > SEUIL_COULEUR) {
    return INCONNUE;
  }
  if (dRouge < dBleu) {
    return ROUGE;
  }
  return BLEU;
}

bool lireCouleur(byte &classe) {
  if (digitalRead(BROCHE_INTER_CAPTEUR) == LOW) {
    return false;
  }
  int r = analogRead(BROCHE_POT_R);
  int g = analogRead(BROCHE_POT_G);
  int b = analogRead(BROCHE_POT_B);
  if (r + g + b < SOMME_MIN) {
    return false;
  }
  classe = classer(r, g, b);
  return true;
}

void gererLecture() {
  bool piecePresente = digitalRead(BROCHE_BOUTON_PIECE) == LOW;
  switch (etatLecture) {
    case ATTENTE:
      if (piecePresente && capteurOk) {
        debutEtat = millis();
        etatLecture = DETECTION;
      } else if (piecePresente && !capteurOk) {
        fifoAjouter(INCONNUE, positionTapis);
        etatLecture = MEMORISATION;
      }
      break;
    case DETECTION:
      if (millis() - debutEtat >= DELAI_CENTRAGE_MS) {
        debutEtat = millis();
        etatLecture = LECTURE;
      }
      break;
    case LECTURE:
      if (lireCouleur(classeLue)) {
        fifoAjouter(classeLue, positionTapis);
        etatLecture = MEMORISATION;
      } else if (millis() - debutEtat >= DELAI_LECTURE_MS) {
        capteurOk = false;
        fifoAjouter(INCONNUE, positionTapis);
        Serial.println("# lecture impossible : piece inconnue");
        etatLecture = MEMORISATION;
      }
      break;
    case MEMORISATION:
      if (!piecePresente) {
        etatLecture = ATTENTE;
      }
      break;
  }
}

int angleDeClasse(byte classe) {
  if (classe == ROUGE) {
    return ANGLE_ROUGE;
  }
  if (classe == BLEU) {
    return ANGLE_BLEU;
  }
  return ANGLE_NEUTRE;
}

void gererTrappe() {
  switch (etatTrappe) {
    case SUIVI:
      if (!fifoVide()) {
        Piece p = fifoTete();
        float avance = positionTapis - p.x0;
        if (avance >= DISTANCE_EJECTION - vitesseLineaire() * TEMPS_TRAPPE) {
          classeEnCours = p.classe;
          trappe.write(angleDeClasse(classeEnCours));
          if (classeEnCours == ROUGE) {
            digitalWrite(BROCHE_LED_ROUGE, HIGH);
          } else if (classeEnCours == BLEU) {
            digitalWrite(BROCHE_LED_BLEU, HIGH);
          }
          etatTrappe = COMMANDE;
        }
      }
      break;
    case COMMANDE:
      if (positionTapis - fifoTete().x0 >= DISTANCE_EJECTION + MARGE_PASSAGE) {
        trappe.write(ANGLE_NEUTRE);
        debutTrappe = millis();
        etatTrappe = RETOUR;
      }
      break;
    case RETOUR:
      if (millis() - debutTrappe >= TEMPS_TRAPPE * 1000) {
        if (classeEnCours == ROUGE) {
          nbRouge++;
        } else if (classeEnCours == BLEU) {
          nbBleu++;
        } else {
          nbInconnue++;
        }
        digitalWrite(BROCHE_LED_ROUGE, LOW);
        digitalWrite(BROCHE_LED_BLEU, LOW);
        fifoRetirer();
        etatTrappe = SUIVI;
      }
      break;
  }
}

void gererAlimentation() {
  float espacement = CONSIGNE * 2.0 * PI / 60.0 * RAYON * ESPACEMENT_S;
  bool autorisee = moteurActif && capteurOk && !fifoPleine();
  if (alimentationEnCours) {
    if (millis() - debutAlimentation >= IMPULSION_ALIMENTATION_MS) {
      digitalWrite(BROCHE_LED_ALIMENTATION, LOW);
      alimentationEnCours = false;
    }
    return;
  }
  if (autorisee && positionTapis - xDerniereAlimentation >= espacement) {
    digitalWrite(BROCHE_LED_ALIMENTATION, HIGH);
    debutAlimentation = millis();
    alimentationEnCours = true;
    xDerniereAlimentation = positionTapis;
  }
}

void afficherJournal() {
  Serial.print(millis() / 1000.0, 1);
  Serial.print(",");
  Serial.print(CONSIGNE, 1);
  Serial.print(",");
  Serial.print(vitesse, 1);
  Serial.print(",");
  Serial.print(commande, 2);
  Serial.print(",");
  Serial.print(nbRouge);
  Serial.print(",");
  Serial.print(nbBleu);
  Serial.print(",");
  Serial.println(nbInconnue);
}

void setup() {
  Serial.begin(9600);
  pinMode(BROCHE_BOUTON_PIECE, INPUT_PULLUP);
  pinMode(BROCHE_INTER_CHARGE, INPUT_PULLUP);
  pinMode(BROCHE_INTER_CAPTEUR, INPUT_PULLUP);
  pinMode(BROCHE_PWM, OUTPUT);
  pinMode(BROCHE_LED_ALIMENTATION, OUTPUT);
  pinMode(BROCHE_SENS_1, OUTPUT);
  pinMode(BROCHE_SENS_2, OUTPUT);
  pinMode(BROCHE_LED_ROUGE, OUTPUT);
  pinMode(BROCHE_LED_BLEU, OUTPUT);
  pinMode(BROCHE_LED_DEFAUT, OUTPUT);
  trappe.attach(BROCHE_SERVO);
  trappe.write(ANGLE_NEUTRE);
  Serial.println("temps,consigne,vitesse,commande,rouge,bleu,inconnue");
}

void loop() {
  surveillerCapteur();
  gererLecture();
  gererTrappe();
  gererAlimentation();
  digitalWrite(BROCHE_LED_DEFAUT, (!capteurOk || !moteurActif) ? HIGH : LOW);
  if (millis() - dernierCalcul >= PERIODE_MS) {
    dernierCalcul = millis();
    simulerMoteur();
    surveillerMoteur();
    regulerVitesse();
    appliquerCommande();
  }
  if (millis() - dernierJournal >= PERIODE_JOURNAL_MS) {
    dernierJournal = millis();
    afficherJournal();
  }
}

using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public static class ConstruireScene
{
    [MenuItem("Ligne de tri/Construire la scene")]
    public static void Construire()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        GameObject lumiere = new GameObject("Lumiere");
        Light l = lumiere.AddComponent<Light>();
        l.type = LightType.Directional;
        lumiere.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

        GameObject sol = GameObject.CreatePrimitive(PrimitiveType.Plane);
        sol.name = "Sol";
        sol.transform.position = new Vector3(1.2f, -0.35f, 0f);
        sol.transform.localScale = new Vector3(0.6f, 1f, 0.4f);
        Colorer(sol, new Color(0.55f, 0.57f, 0.6f));

        GameObject tapis = GameObject.CreatePrimitive(PrimitiveType.Cube);
        tapis.name = "Tapis";
        tapis.transform.position = new Vector3(Parametres.LongueurTapis / 2f, 0f, 0f);
        tapis.transform.localScale = new Vector3(Parametres.LongueurTapis, 0.08f, 0.5f);
        Colorer(tapis, new Color(0.15f, 0.15f, 0.17f));

        GameObject capteur = GameObject.CreatePrimitive(PrimitiveType.Cube);
        capteur.name = "CapteurCouleur";
        capteur.transform.position = new Vector3(Parametres.PositionCapteur, 0.28f, 0f);
        capteur.transform.localScale = new Vector3(0.1f, 0.08f, 0.6f);
        Colorer(capteur, new Color(0.9f, 0.7f, 0.1f));

        GameObject pivot = new GameObject("Trappe");
        pivot.transform.position = new Vector3(Parametres.PositionCapteur + Parametres.DistanceEjection, 0.08f, 0f);
        GameObject volet = GameObject.CreatePrimitive(PrimitiveType.Cube);
        volet.name = "Volet";
        volet.transform.SetParent(pivot.transform, false);
        volet.transform.localPosition = new Vector3(0.15f, 0f, 0f);
        volet.transform.localScale = new Vector3(0.3f, 0.05f, 0.02f);
        Colorer(volet, new Color(0.85f, 0.85f, 0.9f));
        Trappe trappe = pivot.AddComponent<Trappe>();

        Bac(new Vector3(Parametres.LongueurTapis - 0.3f, -0.15f, -0.65f), new Color(0.85f, 0.1f, 0.1f), "BacRouge");
        Bac(new Vector3(Parametres.LongueurTapis - 0.3f, -0.15f, 0.65f), new Color(0.1f, 0.25f, 0.9f), "BacBleu");
        Bac(new Vector3(Parametres.LongueurTapis + 0.4f, -0.15f, 0f), new Color(0.4f, 0.4f, 0.4f), "BacRebut");

        GameObject systeme = new GameObject("Systeme");
        Convoyeur convoyeur = systeme.AddComponent<Convoyeur>();
        Trieur trieur = systeme.AddComponent<Trieur>();
        GenerateurPieces generateur = systeme.AddComponent<GenerateurPieces>();
        HUD hud = systeme.AddComponent<HUD>();
        trieur.convoyeur = convoyeur;
        trieur.generateur = generateur;
        trieur.trappe = trappe;
        generateur.convoyeur = convoyeur;
        generateur.trieur = trieur;
        hud.convoyeur = convoyeur;
        hud.trieur = trieur;
        hud.generateur = generateur;

        GameObject cam = new GameObject("Camera");
        cam.tag = "MainCamera";
        Camera c = cam.AddComponent<Camera>();
        c.clearFlags = CameraClearFlags.SolidColor;
        c.backgroundColor = new Color(0.78f, 0.85f, 0.92f);
        cam.AddComponent<AudioListener>();
        cam.AddComponent<CameraOrbite>();

        string dossier = "Assets/Scenes";
        if (!AssetDatabase.IsValidFolder(dossier))
        {
            AssetDatabase.CreateFolder("Assets", "Scenes");
        }
        EditorSceneManager.SaveScene(scene, dossier + "/LigneDeTri.unity");
        Debug.Log("Scene creee : " + dossier + "/LigneDeTri.unity");
    }

    static void Bac(Vector3 position, Color couleur, string nom)
    {
        GameObject b = GameObject.CreatePrimitive(PrimitiveType.Cube);
        b.name = nom;
        b.transform.position = position;
        b.transform.localScale = new Vector3(0.5f, 0.2f, 0.4f);
        Colorer(b, couleur);
    }

    static void Colorer(GameObject g, Color c)
    {
        Renderer r = g.GetComponent<Renderer>();
        Shader s = Shader.Find("Universal Render Pipeline/Lit");
        if (s == null)
        {
            s = Shader.Find("Standard");
        }
        Material m = new Material(s);
        m.color = c;
        r.sharedMaterial = m;
    }
}

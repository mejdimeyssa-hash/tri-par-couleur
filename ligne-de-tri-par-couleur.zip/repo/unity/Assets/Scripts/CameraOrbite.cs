using UnityEngine;

public class CameraOrbite : MonoBehaviour
{
    public Vector3 cible = new Vector3(1.2f, 0f, 0f);
    public float distance = 4f;
    float yaw = -30f;
    float pitch = 30f;

    void LateUpdate()
    {
        bool appui;
        Vector2 d = Entrees.Souris(out appui);
        if (appui)
        {
            yaw += d.x * 3f;
            pitch = Mathf.Clamp(pitch - d.y * 3f, 5f, 85f);
        }
        Quaternion q = Quaternion.Euler(pitch, yaw, 0f);
        transform.position = cible + q * new Vector3(0f, 0f, -distance);
        transform.LookAt(cible);
    }
}

using UnityEngine;

public class Convoyeur : MonoBehaviour
{
    public float vitesse;
    public float commande;
    public float position;
    public float temperature = 25f;
    public bool moteurActif = true;
    public bool charge;
    public bool surchauffe;

    float integrale;

    void FixedUpdate()
    {
        float dt = Time.fixedDeltaTime;
        float perturbation = charge ? 0.2f * Parametres.Consigne : 0f;
        float u = moteurActif ? commande : 0f;
        float a = Mathf.Exp(-dt / Parametres.TauM);
        vitesse = a * vitesse + (1f - a) * (Parametres.Km * u - perturbation);
        if (vitesse < 0f)
        {
            vitesse = 0f;
        }
        position += Parametres.VitesseLineaire(vitesse) * dt;

        float cible = surchauffe ? 85f : 30f;
        temperature += (cible - temperature) * dt / 6f;
        if (moteurActif && temperature > Parametres.TemperatureMax)
        {
            moteurActif = false;
            integrale = 0f;
        }
        if (!moteurActif && temperature < Parametres.TemperatureReprise)
        {
            moteurActif = true;
        }

        float erreur = Parametres.Consigne - vitesse;
        integrale += Parametres.Ki * dt * erreur;
        commande = Parametres.Kp * erreur + integrale;
        if (commande > 1f)
        {
            integrale -= commande - 1f;
            commande = 1f;
        }
        else if (commande < 0f)
        {
            integrale -= commande;
            commande = 0f;
        }
    }

    public float VitesseLineaire()
    {
        return Parametres.VitesseLineaire(vitesse);
    }
}

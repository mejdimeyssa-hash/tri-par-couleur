using UnityEngine;
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
using UnityEngine.InputSystem;
#endif

public static class Entrees
{
    public static bool Touche(KeyCode code)
    {
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
        Keyboard k = Keyboard.current;
        if (k == null)
        {
            return false;
        }
        switch (code)
        {
            case KeyCode.Alpha1: return k.digit1Key.wasPressedThisFrame;
            case KeyCode.Alpha2: return k.digit2Key.wasPressedThisFrame;
            case KeyCode.Alpha3: return k.digit3Key.wasPressedThisFrame;
            case KeyCode.C: return k.cKey.wasPressedThisFrame;
            case KeyCode.F: return k.fKey.wasPressedThisFrame;
            case KeyCode.T: return k.tKey.wasPressedThisFrame;
            case KeyCode.A: return k.aKey.wasPressedThisFrame;
            case KeyCode.R: return k.rKey.wasPressedThisFrame;
        }
        return false;
#else
        return Input.GetKeyDown(code);
#endif
    }

    public static Vector2 Souris(out bool appui)
    {
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
        Mouse m = Mouse.current;
        if (m == null)
        {
            appui = false;
            return Vector2.zero;
        }
        appui = m.rightButton.isPressed;
        return m.delta.ReadValue() * 0.1f;
#else
        appui = Input.GetMouseButton(1);
        return new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y")) * 3f;
#endif
    }
}

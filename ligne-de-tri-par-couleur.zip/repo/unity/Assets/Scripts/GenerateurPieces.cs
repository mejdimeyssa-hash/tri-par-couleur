using UnityEngine;
using System.Collections.Generic;

public class GenerateurPieces : MonoBehaviour
{
    public Convoyeur convoyeur;
    public Trieur trieur;
    public bool automatique = true;
    public float hauteur = 0.06f;
    public float largeurTapis = 0.5f;
    public List<Piece> pieces = new List<Piece>();

    float xDerniere;
    int compteur;
    Color[] palette = { new Color(0.85f, 0.1f, 0.1f), new Color(0.1f, 0.25f, 0.9f), new Color(0.15f, 0.75f, 0.2f), new Color(0.95f, 0.85f, 0.1f) };

    void Update()
    {
        if (Entrees.Touche(KeyCode.Alpha1)) Creer(0);
        if (Entrees.Touche(KeyCode.Alpha2)) Creer(1);
        if (Entrees.Touche(KeyCode.Alpha3)) Creer(2);
        if (Entrees.Touche(KeyCode.A)) automatique = !automatique;

        float espacement = Parametres.VitesseLineaire(Parametres.Consigne) * Parametres.EspacementS;
        bool autorisee = convoyeur.moteurActif && trieur.capteurOk && !trieur.FifoPleine();
        if (automatique && autorisee && convoyeur.position - xDerniere >= espacement)
        {
            int sequence = compteur % 6;
            int choix = sequence == 5 ? 2 : sequence % 2;
            Creer(choix);
        }
        pieces.RemoveAll(p => p == null);
    }

    public void Creer(int indice)
    {
        xDerniere = convoyeur.position;
        compteur++;
        GameObject g = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        g.name = "Piece_" + compteur;
        g.transform.localScale = new Vector3(0.1f, 0.03f, 0.1f);
        g.transform.position = new Vector3(0f, hauteur, 0f);
        Renderer r = g.GetComponent<Renderer>();
        r.material.color = palette[indice];
        Destroy(g.GetComponent<Collider>());
        Piece p = g.AddComponent<Piece>();
        p.convoyeur = convoyeur;
        p.couleur = palette[indice];
        p.classeReelle = indice == 0 ? Classe.Rouge : (indice == 1 ? Classe.Bleu : Classe.Inconnue);
        p.x0 = convoyeur.position;
        pieces.Add(p);
    }
}

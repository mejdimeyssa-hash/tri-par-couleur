using UnityEngine;

public class HUD : MonoBehaviour
{
    public Convoyeur convoyeur;
    public Trieur trieur;
    public GenerateurPieces generateur;

    float[] historique = new float[300];
    int indice;
    float derniere;
    GUIStyle style;

    void Update()
    {
        if (Time.time - derniere > 0.1f)
        {
            derniere = Time.time;
            historique[indice % historique.Length] = convoyeur.vitesse;
            indice++;
        }
    }

    void OnGUI()
    {
        if (style == null)
        {
            style = new GUIStyle(GUI.skin.label);
            style.fontSize = 16;
            style.normal.textColor = Color.white;
        }
        GUI.Box(new Rect(10, 10, 360, 250), "Ligne de tri par couleur");
        GUI.Label(new Rect(20, 35, 340, 24), "vitesse : " + convoyeur.vitesse.ToString("F1") + " tr/min  (consigne " + Parametres.Consigne + ")", style);
        GUI.Label(new Rect(20, 58, 340, 24), "commande : " + convoyeur.commande.ToString("F2"), style);
        GUI.Label(new Rect(20, 81, 340, 24), "temperature : " + convoyeur.temperature.ToString("F0") + " C", style);
        GUI.Label(new Rect(20, 104, 340, 24), "rouge : " + trieur.nbRouge + "   bleu : " + trieur.nbBleu + "   inconnue : " + trieur.nbInconnue, style);
        GUI.Label(new Rect(20, 127, 340, 24), "lecture : " + trieur.etatLecture + "   trappe : " + trieur.etatTrappe, style);
        GUI.Label(new Rect(20, 150, 340, 24), "charge : " + (convoyeur.charge ? "oui" : "non") + "   capteur : " + (trieur.capteurOk ? "ok" : "defaut") + "   moteur : " + (convoyeur.moteurActif ? "marche" : "arret"), style);
        GUI.Label(new Rect(20, 173, 340, 24), "file : " + trieur.TailleFifo() + "   auto : " + (generateur.automatique ? "oui" : "non"), style);
        GUI.Label(new Rect(20, 196, 340, 24), trieur.dernierEvenement, style);
        GUI.Label(new Rect(20, 225, 340, 24), "1 rouge  2 bleu  3 verte  C charge  F capteur  T chauffe  A auto", style);

        Rect cadre = new Rect(10, Screen.height - 170, 360, 160);
        GUI.Box(cadre, "vitesse (tr/min)");
        Color ancienne = GUI.color;
        GUI.color = Color.green;
        for (int i = 0; i < 299; i++)
        {
            int k = (indice + i) % historique.Length;
            float v = Mathf.Clamp(historique[k], 0f, 60f);
            float h = v / 60f * (cadre.height - 30f);
            GUI.DrawTexture(new Rect(cadre.x + 5 + i * 1.18f, cadre.yMax - 5 - h, 1.5f, 2f), Texture2D.whiteTexture);
        }
        GUI.color = Color.yellow;
        float yc = cadre.yMax - 5 - Parametres.Consigne / 60f * (cadre.height - 30f);
        GUI.DrawTexture(new Rect(cadre.x + 5, yc, cadre.width - 10, 1f), Texture2D.whiteTexture);
        GUI.color = ancienne;
    }
}

using UnityEngine;

public static class Parametres
{
    public const float Consigne = 40f;
    public const float Km = 57.3f;
    public const float TauM = 0.8f;
    public const float TauBF = 0.8f;
    public const float Kp = TauM / (TauBF * Km);
    public const float Ti = TauM;
    public const float Ki = Kp / Ti;

    public const float Rayon = 0.05f;
    public const float DistanceEjection = 1.2f;
    public const float MargePassage = 0.08f;
    public const float TempsTrappe = 0.3f;
    public const float EspacementS = 5f;

    public const float PositionCapteur = 0.5f;
    public const float LongueurTapis = 2.4f;

    public const float AngleRouge = 40f;
    public const float AngleNeutre = 90f;
    public const float AngleBleu = 140f;

    public static readonly Vector2 CentreRouge = new Vector2(0.62f, 0.21f);
    public static readonly Vector2 CentreBleu = new Vector2(0.18f, 0.31f);
    public const float SeuilCouleur = 0.15f;

    public const float DelaiLecture = 0.3f;
    public const float TemperatureMax = 70f;
    public const float TemperatureReprise = 60f;

    public static float VitesseLineaire(float tourMin)
    {
        return tourMin * 2f * Mathf.PI / 60f * Rayon;
    }
}

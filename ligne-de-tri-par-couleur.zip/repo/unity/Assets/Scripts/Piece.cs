using UnityEngine;

public enum Classe { Rouge, Bleu, Inconnue }

public class Piece : MonoBehaviour
{
    public Color couleur;
    public Classe classeReelle;
    public float x0;
    public bool surTapis = true;
    public Vector3 deviation;
    public Convoyeur convoyeur;
    float temps;

    void Update()
    {
        if (surTapis)
        {
            transform.position += Vector3.right * convoyeur.VitesseLineaire() * Time.deltaTime;
            return;
        }
        temps += Time.deltaTime;
        deviation.y -= 9.81f * Time.deltaTime;
        transform.position += deviation * Time.deltaTime;
        if (transform.position.y < -1f || temps > 6f)
        {
            Destroy(gameObject);
        }
    }

    public void Devier(Vector3 direction, float vitesseAvant)
    {
        surTapis = false;
        deviation = new Vector3(vitesseAvant * 0.6f, 0f, 0f) + direction * 0.8f;
    }
}

using UnityEngine;

public class Trappe : MonoBehaviour
{
    public float angle = Parametres.AngleNeutre;
    public float angleCible = Parametres.AngleNeutre;

    void Update()
    {
        angle = Mathf.MoveTowards(angle, angleCible, 300f * Time.deltaTime);
        transform.localRotation = Quaternion.Euler(0f, angle - 90f, 0f);
    }

    public void Ecrire(float a)
    {
        angleCible = a;
    }
}

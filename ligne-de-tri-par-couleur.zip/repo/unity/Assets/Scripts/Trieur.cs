using UnityEngine;
using System.Collections.Generic;

public enum EtatLecture { Attente, Detection, Lecture, Memorisation }
public enum EtatTrappe { Suivi, Commande, Retour }

public class Trieur : MonoBehaviour
{
    public Convoyeur convoyeur;
    public GenerateurPieces generateur;
    public Trappe trappe;

    public EtatLecture etatLecture = EtatLecture.Attente;
    public EtatTrappe etatTrappe = EtatTrappe.Suivi;
    public bool capteurOk = true;
    public bool capteurDebranche;
    public int nbRouge;
    public int nbBleu;
    public int nbInconnue;
    public string dernierEvenement = "";

    struct Entree
    {
        public Classe classe;
        public float x0;
        public Piece piece;
    }

    Queue<Entree> fifo = new Queue<Entree>();
    Piece pieceSousCapteur;
    float debutEtat;
    float debutRetour;
    Classe classeEnCours;
    const int Taille = 8;

    public int TailleFifo()
    {
        return fifo.Count;
    }

    public bool FifoPleine()
    {
        return fifo.Count >= Taille;
    }

    void Update()
    {
        if (Entrees.Touche(KeyCode.C)) convoyeur.charge = !convoyeur.charge;
        if (Entrees.Touche(KeyCode.F)) capteurDebranche = !capteurDebranche;
        if (Entrees.Touche(KeyCode.T)) convoyeur.surchauffe = !convoyeur.surchauffe;

        SurveillerCapteur();
        GererLecture();
        GererTrappe();
    }

    void SurveillerCapteur()
    {
        bool present = !capteurDebranche;
        if (capteurOk && !present)
        {
            capteurOk = false;
            dernierEvenement = "capteur de couleur absent";
        }
        if (!capteurOk && present)
        {
            capteurOk = true;
            dernierEvenement = "capteur de couleur de retour";
        }
    }

    Piece PieceAuCapteur()
    {
        foreach (Piece p in generateur.pieces)
        {
            if (p == null || !p.surTapis)
            {
                continue;
            }
            float x = p.transform.position.x;
            if (Mathf.Abs(x - Parametres.PositionCapteur) < 0.06f)
            {
                return p;
            }
        }
        return null;
    }

    Classe Classer(Color c)
    {
        float somme = c.r + c.g + c.b;
        if (somme < 0.01f)
        {
            return Classe.Inconnue;
        }
        Vector2 m = new Vector2(c.r / somme, c.g / somme);
        float dRouge = Vector2.Distance(m, Parametres.CentreRouge);
        float dBleu = Vector2.Distance(m, Parametres.CentreBleu);
        if (Mathf.Min(dRouge, dBleu) > Parametres.SeuilCouleur)
        {
            return Classe.Inconnue;
        }
        return dRouge < dBleu ? Classe.Rouge : Classe.Bleu;
    }

    void GererLecture()
    {
        Piece p = PieceAuCapteur();
        switch (etatLecture)
        {
            case EtatLecture.Attente:
                if (p != null)
                {
                    pieceSousCapteur = p;
                    if (!capteurOk)
                    {
                        Memoriser(Classe.Inconnue, p);
                        dernierEvenement = "piece inconnue : capteur absent";
                        etatLecture = EtatLecture.Memorisation;
                    }
                    else
                    {
                        debutEtat = Time.time;
                        etatLecture = EtatLecture.Detection;
                    }
                }
                break;
            case EtatLecture.Detection:
                if (Time.time - debutEtat >= 0.06f)
                {
                    debutEtat = Time.time;
                    etatLecture = EtatLecture.Lecture;
                }
                break;
            case EtatLecture.Lecture:
                if (capteurOk && pieceSousCapteur != null)
                {
                    Classe c = Classer(pieceSousCapteur.couleur);
                    Memoriser(c, pieceSousCapteur);
                    if (c == Classe.Inconnue)
                    {
                        dernierEvenement = "couleur inconnue : piece ecartee";
                    }
                    etatLecture = EtatLecture.Memorisation;
                }
                else if (Time.time - debutEtat >= Parametres.DelaiLecture)
                {
                    capteurOk = false;
                    Memoriser(Classe.Inconnue, pieceSousCapteur);
                    dernierEvenement = "lecture impossible : piece inconnue";
                    etatLecture = EtatLecture.Memorisation;
                }
                break;
            case EtatLecture.Memorisation:
                if (p == null || p != pieceSousCapteur)
                {
                    pieceSousCapteur = null;
                    etatLecture = EtatLecture.Attente;
                }
                break;
        }
    }

    void Memoriser(Classe c, Piece p)
    {
        if (FifoPleine())
        {
            return;
        }
        Entree e = new Entree();
        e.classe = c;
        e.x0 = convoyeur.position;
        e.piece = p;
        fifo.Enqueue(e);
    }

    float AngleDeClasse(Classe c)
    {
        if (c == Classe.Rouge) return Parametres.AngleRouge;
        if (c == Classe.Bleu) return Parametres.AngleBleu;
        return Parametres.AngleNeutre;
    }

    void GererTrappe()
    {
        switch (etatTrappe)
        {
            case EtatTrappe.Suivi:
                if (fifo.Count > 0)
                {
                    Entree e = fifo.Peek();
                    float avance = convoyeur.position - e.x0;
                    if (avance >= Parametres.DistanceEjection - convoyeur.VitesseLineaire() * Parametres.TempsTrappe)
                    {
                        classeEnCours = e.classe;
                        trappe.Ecrire(AngleDeClasse(classeEnCours));
                        etatTrappe = EtatTrappe.Commande;
                    }
                }
                break;
            case EtatTrappe.Commande:
                Entree t = fifo.Peek();
                if (t.piece != null && t.piece.surTapis)
                {
                    float x = t.piece.transform.position.x;
                    if (x >= Parametres.PositionCapteur + Parametres.DistanceEjection)
                    {
                        float dir = classeEnCours == Classe.Rouge ? -1f : (classeEnCours == Classe.Bleu ? 1f : 0f);
                        t.piece.Devier(new Vector3(0f, 0f, dir), convoyeur.VitesseLineaire());
                        if (dir == 0f)
                        {
                            t.piece.deviation = new Vector3(convoyeur.VitesseLineaire(), 0f, 0f);
                        }
                    }
                }
                if (convoyeur.position - t.x0 >= Parametres.DistanceEjection + Parametres.MargePassage)
                {
                    trappe.Ecrire(Parametres.AngleNeutre);
                    debutRetour = Time.time;
                    etatTrappe = EtatTrappe.Retour;
                }
                break;
            case EtatTrappe.Retour:
                if (Time.time - debutRetour >= Parametres.TempsTrappe)
                {
                    if (classeEnCours == Classe.Rouge) nbRouge++;
                    else if (classeEnCours == Classe.Bleu) nbBleu++;
                    else nbInconnue++;
                    fifo.Dequeue();
                    etatTrappe = EtatTrappe.Suivi;
                }
                break;
        }
    }
}

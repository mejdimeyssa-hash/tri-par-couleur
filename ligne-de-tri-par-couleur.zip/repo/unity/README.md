# Simulation 3D Unity

Testé sur le papier avec Unity 2022.3 LTS et plus (pipeline Built-in ou URP). Aucun fichier de scène écrit à la main : la scène est générée par un script.

## Mise en route

1. Unity Hub, Add, choisir le dossier `unity/`.
2. Ouvrir le projet, menu **Ligne de tri / Construire la scene**.
3. Ouvrir `Assets/Scenes/LigneDeTri.unity`, puis Play.

## Commandes

| Touche | Action |
|---|---|
| 1 / 2 / 3 | pièce rouge / bleue / verte (inconnue) |
| A | alimentation automatique on/off |
| C | charge +20 % |
| F | débrancher le capteur de couleur |
| T | échauffement du moteur |
| clic droit + souris | tourner la caméra |

## Scripts

| Script | Rôle |
|---|---|
| `Parametres.cs` | constantes communes (identiques à l'Arduino) |
| `Convoyeur.cs` | moteur du premier ordre, PI, anti-windup, température |
| `Trieur.cs` | machine de lecture, FIFO, machine de la trappe |
| `Trappe.cs` | servo de la trappe |
| `GenerateurPieces.cs` | pièces cadencées par la distance du tapis |
| `Piece.cs` | déplacement et chute de la pièce |
| `HUD.cs` | affichage et courbe de vitesse |
| `Entrees.cs` | clavier compatible ancien et nouveau Input System |
